export type ExampleType =
  | 'BASIC'
  | 'LIGHT'