Link
https://sketchfab.com/models/edd1c604e1e045a0a2a552ddd9a293e6

Artist: antonmoek
https://sketchfab.com/antonmoek

Licence: CC-BY 4.0
http://creativecommons.org/licenses/by/4.0/