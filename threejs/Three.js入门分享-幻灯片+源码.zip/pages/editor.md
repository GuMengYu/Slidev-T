# 可视化编辑器

集成加载3d模型到大屏中的能力(采用unniv-sdk - 基于threejs再次封装的库)

<div class="flex justify-center">

<img src="/images/editor.png" style="max-width: 85%" >

</div>

