# 一个小场景

<ThreeJs type="ROAD" :width="868" />