# 其他
 1. 物体的交互, 轨道控制
 2. geometry texture更高级的用法
 3. 物理效果
 4. 粒子系统
 5. shader语言 （GLSL opengl着色器语言）
 ...

