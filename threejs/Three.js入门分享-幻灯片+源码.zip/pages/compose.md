# Three.js 程序的组成
> Three.js 有很多图元。图元就是一些 3D 的形状，在运行时根据大量参数生成。
<div grid="~ cols-2 gap-4" m="-t-2">
    <img border="rounded" src="/images/compose.png">
    <img border="rounded" src="/images/compose2.png" :width="350"> 
</div>

[Learn More](https://threejs.org/manual/#zh/primitives)
